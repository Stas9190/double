<?php
$DATABASES = [
    "MySql" => [
        "NAME" => "testing_system",
        "HOST" => "localhost",
        "USER" => "root",
        "PASSWORD" => "",
        "CHARSET" => "SET NAMES utf8",
        "DRIVER" => "mysql" //не обязательно (по умолчанию mysql)
    ]
];

$BASE_FILE = 'base.php';
?>
